# Imperacraft – Diário de Exploração

Checklist interativa de mods, bosses e dungeons do modpack Imperacraft.
Site estático: tudo está em `site/index.html`.

## Publicar (uma vez só)
1. Crie um repositório no GitHub (ex.: `imperacraft`) e envie estes arquivos.
2. Em **Settings → Pages**, escolha **Source: GitHub Actions**.
3. Faça um push na branch `main`. Em alguns minutos o site fica em
   `https://SEU-USUARIO.github.io/imperacraft/`.

## Atualizar o site
- **Pelo navegador:** abra `site/index.html` no GitHub, clique no lápis ou em
  *Upload files*, substitua pelo novo arquivo e faça o commit.
- **Pelo terminal:** `./atualizar.sh ~/Downloads/imperacraft-checklist.html`

Cada push na `main` dispara o workflow em `.github/workflows/pages.yml`
e republica o site automaticamente.

## Domínio próprio (opcional)
Em Settings → Pages → Custom domain.
